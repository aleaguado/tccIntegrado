/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Beans.Cliente;
import Beans.Funcionario;
import gestaodevarejo.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gabriel Poli
 */
public class FuncionarioDAO {
    private Connection con;
    private String erro;

    public String getErro() {
        return this.erro;
    }
    
    public FuncionarioDAO(){
    this.con = Conexao.conectar();
    
    
}
    
    public boolean inserirFuncionario(Funcionario f){
    String insere = "INSERT INTO funcionario (idfuncionario,cpf,senha,nome,telefone,email,endereco,status) VALUES (?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement stmte = this.con.prepareStatement(insere);
            
        stmte.setInt(1,f.getIdFuncionario());
        stmte.setString(2,f.getCPF());
        stmte.setString(3,f.getSenha());
        stmte.setString(4,f.getNome());
        stmte.setString(5,f.getTelefone());
        stmte.setString(6,f.getEmail());
        stmte.setString(7,f.getEndereco());
        stmte.setBoolean(8,f.isStatus());
        stmte.execute();
        
        return true;
        } catch (Exception e) {
            this.erro = "Erro ao inserir: " + e.getMessage();
            return false;
        }
    }
    public List<Funcionario> pesquisarFuncionariobyFiltro(String filtro,String valor){
    String consulta = "SELECT * FROM funcionario WHERE "+ filtro +" LIKE ?";
        
        try{
            PreparedStatement stmte = this.con.prepareStatement(consulta);
            stmte.setString(1, "%" + valor + "%");
            ResultSet rs = stmte.executeQuery();
            List<Funcionario> listaFuncionario = new ArrayList();
            
            while(rs.next()){
                Funcionario f = new Funcionario();
                
                f.setNome(rs.getString("nome"));
                f.setCPF(rs.getString("cpf"));
                f.setTelefone(rs.getString("telefone"));
                f.setEndereco(rs.getString("endereco"));
                f.setStatus(rs.getBoolean("status"));
                listaFuncionario.add(f);
            }
            return listaFuncionario;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            this.erro = "Erro ao buscar os funcionario";
            return null;
        }
    }
    public boolean alterarFuncionario(Funcionario f){
    
        String update = "UPDATE funcionario SET endereco = ?, telefone = ?, email = ?, status = ? WHERE nome = ?";
        try {
            
             PreparedStatement stmt = this.con.prepareStatement(update);  
             stmt.setString(1,f.getEndereco());
             stmt.setString(2,f.getTelefone());
             stmt.setString(3, f.getEmail());
             stmt.setBoolean(4, f.isStatus());
             stmt.setString(5, f.getNome());
             stmt.executeUpdate();  
    
            return true;
        } catch (Exception e) {
            this.erro = "Erro ao Atualizar dados";
            return false;
        }
    }
}
