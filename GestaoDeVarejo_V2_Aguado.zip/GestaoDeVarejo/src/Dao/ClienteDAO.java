/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Beans.Cliente;
import gestaodevarejo.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author IFSP
 */
public class ClienteDAO {

    private Connection con;
    private String erro;

    public String getErro() {
        return this.erro;
    }

    public ClienteDAO() {
        this.con = Conexao.conectar();
    }

    public boolean inserirCliente(Cliente c) {
        String insere = "INSERT INTO cliente (idcliente,cpf,nome,telefone,email,endereco,status) VALUES (?,?,?,?,?,?,?)";
        /*String FKVenda=("INSERT INTO venda (idvenda,data,valor,status,quantidade_parcela,funcionario_idfuncionario,cliente_idcliente) "
                + "VALUES(?,?,?,?,?,?,LAST_INSERT_ID())");*///last_insert... retorna o ultimo id que foi incrementado antes da querry que o cita ou seja  retorna ultimo id incrementado da tabela pessoa
        try {
            PreparedStatement stmte = this.con.prepareStatement(insere);

            stmte.setInt(1, c.getIdcliente());
            stmte.setString(2, c.getCPF());
            stmte.setString(3, c.getNome());
            stmte.setString(4, c.getTelefone());
            stmte.setString(5, c.getEmail());
            stmte.setString(6, c.getEndereco());
            stmte.setBoolean(7, c.isStatus());
            stmte.execute();

            return true;
        } catch (Exception e) {
            this.erro = "Erro ao inserir: " + e.getMessage();
            return false;
        }

    }

    public List<Cliente> pesquisarClientebyFiltro(String filtro, String valor) {
        String consulta = "SELECT * FROM cliente WHERE " + filtro + " LIKE ?";

        try {
            PreparedStatement stmte = this.con.prepareStatement(consulta);
            stmte.setString(1, "%" + valor + "%");
            ResultSet rs = stmte.executeQuery();
            List<Cliente> listaCliente = new ArrayList();

            while (rs.next()) {
                Cliente c = new Cliente();

                c.setNome(rs.getString("nome"));
                c.setCPF(rs.getString("cpf"));
                c.setTelefone(rs.getString("telefone"));
                c.setEndereco(rs.getString("endereco"));
                c.setStatus(rs.getBoolean("status"));
                listaCliente.add(c);
            }
            return listaCliente;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            this.erro = "Erro ao buscar os funcionario";
            return null;
        }
    }

    public List<Cliente> pesquisarCliente(String valor) {
        String consulta = "SELECT * FROM cliente WHERE nome LIKE ?";

        try {
            PreparedStatement stmte = this.con.prepareStatement(consulta);
            stmte.setString(1, "%" + valor + "%");
            ResultSet rs = stmte.executeQuery();
            List<Cliente> listaCliente = new ArrayList();

            while (rs.next()) {
                Cliente c = new Cliente();
                c.setIdcliente(rs.getInt("idcliente"));
                c.setNome(rs.getString("nome"));
                listaCliente.add(c);
            }
            return listaCliente;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            this.erro = "Erro ao buscar os Clientes";
            return null;
        }
    }

    public boolean alterarCliente(Cliente c) {

        String update = "UPDATE cliente SET endereco = ?, telefone = ?, email = ?, status = ? WHERE nome = ?";
        try {

            PreparedStatement stmt = this.con.prepareStatement(update);
            stmt.setString(1, c.getEndereco());
            stmt.setString(2, c.getTelefone());
            stmt.setString(3, c.getEmail());
            stmt.setBoolean(4, c.isStatus());
            stmt.setString(5, c.getNome());
            stmt.executeUpdate();

            return true;
        } catch (Exception e) {
            this.erro = "Erro ao Atualizar dados";
            return false;
        }
    }

}
