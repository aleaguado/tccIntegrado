/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Beans.Cliente;
import Beans.Estoque;
import Beans.Funcionario;
import Beans.Venda;
import gestaodevarejo.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gabriel Poli
 */
public class VendaDAO {

    private Connection con;
    private String erro;

    public String getErro() {
        return erro;
    }

    public VendaDAO() {
        this.con = Conexao.conectar();
    }

    public boolean adicionaVenda(Venda v) {
        String sql = "insert into venda ( idvenda,data, valor , status , quantidade_parcela) values (?,?,?,?,?)";

        try {
            PreparedStatement stmt = this.con.prepareStatement(sql);
            stmt.setInt(1, v.getIdVenda());
            stmt.setDate(2, (Date) v.getData());
            stmt.setFloat(3, v.getValor());
            stmt.setBoolean(4, v.isStatus());
            stmt.setInt(5, v.getQuantidadeParcela());
            stmt.execute();
            return true;
        } catch (Exception e) {
            this.erro = "Venda não realizada: " + e.getMessage();
            return false;
        }
    }
    public void vendaProduto(Venda v){
        String vende = "INSERT INTO venda(idvenda,data, valor , status , quantidade_parcela) SELECT * FROM venda, venda_produto"
                + "INNER JOIN ON varejo.venda.idvenda = varejo.venda_produto.venda_idvenda"
                + "INNER JOIN ON varejo.venda_produto.produto_idproduto = varejo.produto.idproduto"
                + "INNER JOIN ON varejo.venda.funcionario_idfuncionario = varejo.funcionario.idfuncionario"
                + "INNER JOIN ON varejo.cliente.idcliente = varejo.venda.cliente_idcliente";
    }
    
    

    public List<Venda> consultaDeVenda(Cliente c, Venda v, Funcionario f, Estoque e) {
        ArrayList dados = new ArrayList();
        ArrayList listaAux = new ArrayList();
        String consulta = "SELECT varejo.cliente.idcliente, varejo.venda.data, varejo.venda.valor, varejo.venda.quantidade_parcela, varejo.funcionario.idfuncionario, varejo.produto.nome FROM venda "
                + "INNER JOIN cliente ON venda.cliente_idcliente = cliente.idcliente "
                + "INNER JOIN venda_produto ON venda.idvenda = venda_produto.venda_idvenda  "
                + "INNER JOIN produto ON venda_produto.produto_idproduto = produto.idproduto "
                + "INNER JOIN funcionario ON venda.funcionario_idfuncionario = funcionario.idfuncionario";

        try {
            Statement stmte = this.con.createStatement();
            ResultSet rs = stmte.executeQuery(consulta);
            while (rs.next()) {

                c.setIdcliente(rs.getInt("idcliente"));

                v.setData(rs.getDate("data"));
                v.setValor(rs.getFloat("valor"));
                v.setQuantidadeParcela(rs.getInt("quantidade_parcela"));

                f.setIdFuncioario(rs.getInt("idfuncionario"));

                e.setNome(rs.getString("nome"));
                dados.add(c);
                dados.add(v);
                dados.add(f);
                dados.add(e);

                listaAux.add(dados);
            }
            return listaAux;
        } catch (Exception exception) {
            this.erro = exception.getMessage();
            return null;
        }
    }

    public List<Venda> relatorioDeVenda(Venda v, Funcionario f, Estoque e) {
        ArrayList dados = new ArrayList();
        ArrayList listaAux = new ArrayList();
        String consulta = "SELECT  varejo.venda.data, varejo.venda.valor, varejo.venda.quantidade_parcela, varejo.funcionario.idfuncionario, varejo.produto.nome FROM venda "
                + "INNER JOIN venda_produto ON venda.idvenda = venda_produto.venda_idvenda  "
                + "INNER JOIN produto ON venda_produto.produto_idproduto = produto.idproduto "
                + "INNER JOIN funcionario ON venda.funcionario_idfuncionario = funcionario.idfuncionario";

        try {
            Statement stmte = this.con.createStatement();
            ResultSet rs = stmte.executeQuery(consulta);
            while (rs.next()) {

                v.setData(rs.getDate("data"));
                v.setValor(rs.getFloat("valor"));
                v.setQuantidadeParcela(rs.getInt("quantidade_parcela"));

                f.setIdFuncioario(rs.getInt("idfuncionario"));

                e.setNome(rs.getString("nome"));

                dados.add(v);
                dados.add(f);
                dados.add(e);

                listaAux.add(dados);
            }
            return listaAux;

        } catch (Exception exception) {
            this.erro = exception.getMessage();
            return null;
        }

    }
}
