/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Beans.Funcionario;
import Beans.Usuario;

import gestaodevarejo.Conexao;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.ResultSet;

/**
 *
 * @author IFSP
 */
//REPARA QUE COLOQUEI ELA EXTENDENDO GENERICDAO!!!
public class UsuarioDAO extends GenericDAO{
   // private Connection con;
    private String erro;

    public String getErro() {
        return erro;
    }
    
    public void UsuarioDAO(){
        //this.con = Conexao.conectar();
                
        
        
}
    public boolean inserirAdmin(Usuario u){
        
        String inseread = "INSERT INTO admin() VALUES(?,?)";
        try {
            
            PreparedStatement stmte = conn.prepareStatement(inseread);
            System.out.println("Ate aqui foi");
            stmte.setString(1,u.getIdusuario());
            System.out.println("Ate aqui foi");
           if(md5(u.getSenha()).equals("")){
        this.erro = "Nao pode criptografar senha";
        
        }
        stmte.setString(2,md5(u.getSenha()));
        stmte.execute();
            return true;
        } catch (Exception e) {
            this.erro = "Erro ao inserir: " + e.getMessage();
            return false;
        }
    }
    public String md5(String c){
        try {
            MessageDigest digs= MessageDigest.getInstance("MD5");
            digs.update((c).getBytes("UTF8"));
            String stf = new String(digs.digest());
            return stf;
            
        } catch (Exception e) {
            this.erro = "Erro ao criptografar: " + e.getMessage();
            return "";
        }
    }
    
    public boolean autenticar(Funcionario u)
    {
        String autenticar = "SELECT * FROM funcionario WHERE cpf = ? AND senha = ?";
        
        try{
            PreparedStatement stmte = conn.prepareStatement(autenticar);
            stmte.setString(1, u.getCPF());
            stmte.setString(2, u.getSenha());
            ResultSet rs = stmte.executeQuery();
            
            while(rs.next()){
                return true;
            }
        }
        catch(Exception e){
            this.erro = e.getMessage();
            return false;
        }
        return false;
    }
    public boolean autenticarAdmin(Usuario u)
    {
        String autenticar = "SELECT * FROM admin WHERE usuario = ? AND senha = ?";
        
        try{
            PreparedStatement stmte = conn.prepareStatement(autenticar);
            stmte.setString(1, u.getIdusuario());
            stmte.setString(2, u.getSenha());
            ResultSet rs = stmte.executeQuery();
            
            while(rs.next()){
                
                return true;
            }
        }
        catch(Exception e){
            this.erro = e.getMessage();
            return false;
        }
        return false;
    }
}
