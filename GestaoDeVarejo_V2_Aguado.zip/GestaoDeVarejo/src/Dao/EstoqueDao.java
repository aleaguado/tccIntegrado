/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Beans.Cliente;
import Beans.Estoque;
import com.sun.org.apache.xml.internal.dtm.DTM;
import gestaodevarejo.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author IFSP
 */
public class EstoqueDao {
    private Connection con;
    private String erro;

    public String getErro() {
        return erro;
    }
    
    public EstoqueDao(){
        this.con = Conexao.conectar();
    }
    public boolean insereNoEstoque(Estoque es){
        String insere = "INSERT INTO produto (idproduto,nome,preco,quantidade,descricao) values (?,?,?,?,?)";
        
        try {
            PreparedStatement stmte = this.con.prepareStatement(insere);
            stmte.setInt(1,es.getIdProduto());
            stmte.setString(2, es.getNome());
            stmte.setDouble(3, es.getPreco());
            stmte.setInt(4,es.getQuantidade());
            stmte.setString(5, es.getDescricao());
            stmte.execute();
            return true;
        } catch (Exception e) {
            this.erro = "Erro ao inserir produto no Estoque";
            return false;
        }
    }
    public List<Estoque> pesquisarEstoquebyFiltro(String filtro,String valor){
    String consulta = "SELECT * FROM produto WHERE "+ filtro +" LIKE ?";
        
        try{
            PreparedStatement stmte = this.con.prepareStatement(consulta);
            stmte.setString(1, "%" + valor + "%");
            ResultSet rs = stmte.executeQuery();
            List<Estoque> listaEstoque = new ArrayList();
            
            while(rs.next()){
                Estoque es = new Estoque();
                
                es.setNome(rs.getString("nome"));
                es.setIdProduto(rs.getInt("idproduto"));
                es.setPreco(rs.getDouble("preco"));
                es.setQuantidade(rs.getInt("quantidade"));
                listaEstoque.add(es);
            }
            return listaEstoque;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            this.erro = "Erro ao buscar os produtos";
            return null;
        }
    }
    public List<Estoque> pesquisarPrecoEstoquebyFiltro(String filtro, Double valord){
    String consulta = "SELECT * FROM produto WHERE "+ filtro +" LIKE ?";
        
        try{
            PreparedStatement stmte = this.con.prepareStatement(consulta);
            stmte.setString(1, "%" + valord + "%");
            ResultSet rs = stmte.executeQuery();
            List<Estoque> listaEstoque = new ArrayList();
            
            while(rs.next()){
                Estoque es = new Estoque();
                
                es.setNome(rs.getString("nome"));
                es.setIdProduto(rs.getInt("idproduto"));
                es.setPreco(rs.getDouble("preco"));
                es.setQuantidade(rs.getInt("quantidade"));
                listaEstoque.add(es);
            }
            return listaEstoque;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            this.erro = "Erro ao buscar os produtos";
            return null;
        }
    }
    public List<Estoque> pesquisarTodosProdutos(){
    String consulta = "SELECT * FROM produto";
        
        try{
            PreparedStatement stmte = this.con.prepareStatement(consulta);
            ResultSet rs = stmte.executeQuery();
            List<Estoque> listaEstoque = new ArrayList();
            
            while(rs.next()){
                Estoque es = new Estoque();
                
                es.setNome(rs.getString("nome"));
                es.setIdProduto(rs.getInt("idproduto"));
                es.setPreco(rs.getDouble("preco"));
                es.setQuantidade(rs.getInt("quantidade"));
                listaEstoque.add(es);
            }
            return listaEstoque;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            this.erro = "Erro ao buscar os produtos";
            return null;
        }
    }
     public List<Estoque> pesquisarEstoquebyFiltro(String valor){
    String consulta = "SELECT * FROM produto WHERE idproduto LIKE ?";
        
        try{
            PreparedStatement stmte = this.con.prepareStatement(consulta);
            stmte.setString(1, "%" + valor + "%");
            ResultSet rs = stmte.executeQuery();
            List<Estoque> listaEstoque = new ArrayList();
            
            while(rs.next()){
                Estoque es = new Estoque();
                
                es.setIdProduto(rs.getInt("idproduto"));
                es.setNome(rs.getString("nome"));
                es.setPreco(rs.getDouble("preco"));
                
                listaEstoque.add(es);
            }
            return listaEstoque;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            this.erro = "Erro ao buscar os produtos";
            return null;
        }
    }
    /*public void CarregarTabela() {

         String SQL = "SELECT codigo,nome,telefone,email FROM Tabela where nome like '%"+ cmbPesquisar.getText() +"'%'";
         try {

             PreparedStatement stmte = Conexao.conectar().prepareStatement(SQL);
             ResultSet rs = stmte.executeQuery();
             int QuantidadeColunas = rs.getMetaData().getColumnCount();
             DefaultTableModel tabelaProduto = (DefaultTableModel) tblProduto.getModel();
             tabelaProduto.setNumRows(0);
             while (rs.next()) {
                  String Dados[] = new String[QuantidadeColunas];
                  for (int I = 1; I <= QuantidadeColunas; I++) {
                  Dados[I-1] = rs.getString(I);

                  }     

                  tabelaProduto.addRow(Dados);
                  } 

             } catch (Exception e) {
             JOptionPane.showMessageDialog(null,"Falha ao Carregar a Tabela!\n" + e.toString());
         }  
      }*/
}
