/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

/**
 *
 * @author IFSP
 */
public class Usuario {
    private String idUsuario;
    private String senha;

    public String getIdusuario() {
        return idUsuario;
    }

    public void setIdusuario(String idusuario) {
        this.idUsuario = idusuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
