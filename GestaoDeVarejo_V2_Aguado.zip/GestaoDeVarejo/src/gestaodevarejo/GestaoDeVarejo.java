/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestaodevarejo;

import Beans.Usuario;
import Dao.UsuarioDAO;
import Forms.FormAcesso;



/**
 *
 * @author IFSP
 */
public class GestaoDeVarejo {
    private UsuarioDAO usuarioDAO;
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        FormAcesso login = new FormAcesso();
        login.setVisible(true);
    }
    
}
