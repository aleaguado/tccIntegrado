/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestaodevarejo;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;

/**
 *
 * @author IFSP
 */
public class Conexao {
    private static Connection conexao = null;
    public static Connection conectar()
    {
        try{
            return DriverManager.getConnection("jdbc:mysql://localhost/varejo", "root", "Ung1v3up");
        }
        catch(Exception e){
            System.out.println("Erro ao conectar: " + e.getMessage());
            return null;
        }
    }
    protected static void desconectar(){/*Protected: Esse é o que pega mais gente, ele é praticamente igual ao default,
        com a diferença de que se uma classe (mesmo que esteja fora do pacote) estende da classe com o atributo protected,
        ela terá acesso a ele.
        Então o acesso é por pacote e por herança.*/
        try{
            conexao.close();
        }
        catch(Exception ex){
            System.out.print("SQLException: ");
            System.out.println(ex.getMessage());
        }
    }
}
